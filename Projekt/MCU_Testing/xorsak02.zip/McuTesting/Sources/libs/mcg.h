/**
 * author: unknown
 */

#ifndef MCG_H_
#define MCG_H_

void MCG_FEI_BLPE();
void MCG_BLPE_FEI();


#endif /* MCG_H_ */
