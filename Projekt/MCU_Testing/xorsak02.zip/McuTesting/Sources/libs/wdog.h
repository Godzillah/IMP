/**
 * author  : Maro� Ors�k (xorsak02)
 * file	   : wdog.h
 * created : 21.11.2019
 */


#ifndef SOURCES_WDOG_H_
#define SOURCES_WDOG_H_

#include "MK60D10.h"
#include "libs/io.h"
#include "libs/gpio.h"

void wdogResetInvokeExample();

#endif /* SOURCES_WDOG_H_ */
